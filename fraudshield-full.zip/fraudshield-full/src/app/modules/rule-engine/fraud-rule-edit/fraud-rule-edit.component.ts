import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RuleEngineService } from '../../../services/rule-engine.service';

@Component({
  selector: 'app-fraud-rule-edit',
  templateUrl: './fraud-rule-edit.component.html',
  styleUrls: ['./fraud-rule-edit.component.css']
})
export class FraudRuleEditComponent implements OnInit {
  model: any = { ruleName:'', description:'', thresholdValue:0 };
  id: number = 0;

  constructor(private route: ActivatedRoute, private svc: RuleEngineService, private router: Router){}

  ngOnInit(){
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.svc.getRule(this.id).subscribe(r => this.model = r);
  }

  save(){
    this.svc.updateRule(this.id, this.model).subscribe(()=> this.router.navigate(['/rule-engine']));
  }

  cancel(){ this.router.navigate(['/rule-engine']); }
}
