import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FraudRule } from '../models/fraud-rule.model';
import { RuleViolation } from '../models/violation.model';

@Injectable({ providedIn: 'root' })
export class RuleEngineService {
  private api = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  getRules(): Observable<FraudRule[]> { return this.http.get<FraudRule[]>(`${this.api}/fraudRules`); }
  getRule(id:number){ return this.http.get<FraudRule>(`${this.api}/fraudRules/${id}`); }
  addRule(rule: any){ return this.http.post(`${this.api}/fraudRules`, rule); }
  updateRule(id:number, rule:any){ return this.http.put(`${this.api}/fraudRules/${id}`, rule); }
  deleteRule(id:number){ return this.http.delete(`${this.api}/fraudRules/${id}`); }

  getViolations(): Observable<RuleViolation[]> { return this.http.get<RuleViolation[]>(`${this.api}/ruleViolations`); }
}
