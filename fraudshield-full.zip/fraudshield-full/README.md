# FraudShield Frontend (Full scaffold)

This is a ready-to-open Angular frontend project scaffold for the FraudShield Rule Engine module.
It uses json-server as a mock backend.

## Setup

1. Install dependencies
```
npm install
```

2. Start mock API
```
npm run mock-api
```

3. In another terminal start Angular
```
npm start
```

Open http://localhost:4200
Mock API at http://localhost:3000

