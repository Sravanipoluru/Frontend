import { Component, OnInit } from '@angular/core';
import { RuleEngineService } from '../../../services/rule-engine.service';

@Component({
  selector: 'app-violation-list',
  templateUrl: './violation-list.component.html',
  styleUrls: ['./violation-list.component.css']
})
export class ViolationListComponent implements OnInit {
  violations: any[] = [];
  constructor(private svc: RuleEngineService){}
  ngOnInit(){ this.svc.getViolations().subscribe(v=> this.violations = v); }
}
