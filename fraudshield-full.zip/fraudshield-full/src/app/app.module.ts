import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { FraudRuleListComponent } from './modules/rule-engine/fraud-rule-list/fraud-rule-list.component';
import { FraudRuleAddComponent } from './modules/rule-engine/fraud-rule-add/fraud-rule-add.component';
import { FraudRuleEditComponent } from './modules/rule-engine/fraud-rule-edit/fraud-rule-edit.component';
import { ViolationListComponent } from './modules/rule-engine/violation-list/violation-list.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FraudRuleListComponent,
    FraudRuleAddComponent,
    FraudRuleEditComponent,
    ViolationListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
