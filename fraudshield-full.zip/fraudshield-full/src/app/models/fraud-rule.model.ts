export interface FraudRule {
  id?: number;
  ruleName: string;
  description?: string;
  thresholdValue?: number;
}
