import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RuleEngineService } from '../../../services/rule-engine.service';

@Component({
  selector: 'app-fraud-rule-add',
  templateUrl: './fraud-rule-add.component.html',
  styleUrls: ['./fraud-rule-add.component.css']
})
export class FraudRuleAddComponent {
  model = { ruleName:'', description:'', thresholdValue:0 };

  constructor(private svc: RuleEngineService, private router: Router) {}

  save(){
    if(!this.model.ruleName){ alert('Rule Name required'); return; }
    this.svc.addRule(this.model).subscribe(()=> this.router.navigate(['/rule-engine']));
  }

  cancel(){ this.router.navigate(['/rule-engine']); }
}
