import { Component } from '@angular/core';

@Component({
  template: `
    <h2>Welcome to FraudShield</h2>
    <p>This frontend demonstrates a rule-based fraud engine UI using a json-server mock API.</p>
    <p>Use the <strong>Rules</strong> page to add/edit rules, and <strong>Violations</strong> to view sample violations.</p>
  `
})
export class HomeComponent {}
