export interface RuleViolation {
  id?: number;
  claimId: number;
  ruleId: number;
  violationDate: string;
}
