import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RuleEngineService } from '../../../services/rule-engine.service';

@Component({
  selector: 'app-fraud-rule-list',
  templateUrl: './fraud-rule-list.component.html',
  styleUrls: ['./fraud-rule-list.component.css']
})
export class FraudRuleListComponent implements OnInit {
  rules: any[] = [];
  violations: any[] = [];

  constructor(private svc: RuleEngineService, private router: Router) {}

  ngOnInit() {
    this.load();
  }

  load(){
    this.svc.getRules().subscribe(r=> this.rules = r);
    this.svc.getViolations().subscribe(v=> this.violations = v);
  }

  add(){ this.router.navigate(['/rule-engine/add']); }
  edit(id:any){ this.router.navigate(['/rule-engine/edit', id]); }
  remove(id:number){
    if(confirm('Delete rule?')) {
      this.svc.deleteRule(id).subscribe(()=> this.load());
    }
  }
}
