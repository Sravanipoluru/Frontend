import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FraudRuleListComponent } from './modules/rule-engine/fraud-rule-list/fraud-rule-list.component';
import { FraudRuleAddComponent } from './modules/rule-engine/fraud-rule-add/fraud-rule-add.component';
import { FraudRuleEditComponent } from './modules/rule-engine/fraud-rule-edit/fraud-rule-edit.component';
import { ViolationListComponent } from './modules/rule-engine/violation-list/violation-list.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'rule-engine', component: FraudRuleListComponent },
  { path: 'rule-engine/add', component: FraudRuleAddComponent },
  { path: 'rule-engine/edit/:id', component: FraudRuleEditComponent },
  { path: 'violations', component: ViolationListComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
